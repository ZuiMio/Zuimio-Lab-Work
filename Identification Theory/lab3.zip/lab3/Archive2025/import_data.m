%% 从文本文件中导入数据
% 用于从以下文本文件中导入数据的脚本:
%
%    filename: /Users/zuimio/Desktop/ITMO/s7/Identification Theory/labs/lab9/Archive2025/data.csv
%
% 由 MATLAB 于 2025-12-09 13:58:43 自动生成

%% 设置导入选项并导入数据
opts = delimitedTextImportOptions("NumVariables", 19);

% 指定范围和分隔符
opts.DataLines = [2, Inf];
opts.Delimiter = ",";

% 指定列名称和类型
opts.VariableNames = ["index", "kitchen_area", "bath_area", "other_area", "gas", "hot_water", "central_heating", "extra_area", "extra_area_count", "year", "ceil_height", "floor_max", "floor", "total_area", "bath_count", "extra_area_type_name", "district_name", "rooms_count", "price"];
opts.VariableTypes = ["double", "double", "double", "double", "categorical", "categorical", "categorical", "double", "double", "double", "double", "double", "double", "double", "double", "categorical", "categorical", "double", "double"];

% 指定文件级属性
opts.ExtraColumnsRule = "ignore";
opts.EmptyLineRule = "read";

% 指定变量属性
opts = setvaropts(opts, ["gas", "hot_water", "central_heating", "extra_area_type_name", "district_name"], "EmptyFieldRule", "auto");

% 导入数据
data = readtable("/Users/zuimio/Desktop/ITMO/s7/Identification Theory/labs/lab9/Archive2025/data.csv", opts);


%% 清除临时变量
clear opts