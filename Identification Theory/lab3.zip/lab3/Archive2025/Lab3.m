%% 
clear; clc;

%% 1. data
train_data = readtable('data.csv');
test_data = readtable('test.csv');

%% 2. Data Preprocessing
% Convert categorical variables to category type
cat_vars = {'gas', 'hot_water', 'central_heating', 'extra_area_type_name', 'district_name'};
for i = 1:length(cat_vars)
    if ismember(cat_vars{i}, train_data.Properties.VariableNames)
        train_data.(cat_vars{i}) = categorical(train_data.(cat_vars{i}));
        test_data.(cat_vars{i}) = categorical(test_data.(cat_vars{i}));
    end
end

% Filling Numeric Variables with the Median
numeric_vars = {'area', 'rooms', 'bathrooms', 'floor', 'year_built'};
for i = 1:length(numeric_vars)
    if ismember(numeric_vars{i}, train_data.Properties.VariableNames)
        train_median = median(train_data.(numeric_vars{i}), 'omitnan');
        train_data.(numeric_vars{i})(isnan(train_data.(numeric_vars{i}))) = train_median;
        test_data.(numeric_vars{i})(isnan(test_data.(numeric_vars{i}))) = train_median;
    end
end

% Create New Features
if ismember('year_built', train_data.Properties.VariableNames)
    current_year = 2023;
    train_data.house_age = current_year - train_data.year_built;
    test_data.house_age = current_year - test_data.year_built;
end

if ismember('area', train_data.Properties.VariableNames) && ismember('rooms', train_data.Properties.VariableNames)
    train_data.room_density = train_data.area ./ (train_data.rooms + 1);
    test_data.room_density = test_data.area ./ (test_data.rooms + 1);
end

%% 3
% Exclude unnecessary columns
exclude_vars = {'price', 'index'};
predictors = train_data.Properties.VariableNames;
predictors = predictors(~ismember(predictors, exclude_vars));

% Prepare training data
X_train = train_data(:, predictors);
y_train = train_data.price;

%% 4. Train a random forest model
num_trees = 300;  
model = TreeBagger(num_trees, X_train, y_train, ...
    'Method', 'regression', ...
    'MinLeafSize', 5, ...      
    'OOBPredictorImportance', 'on'); 

%% 5. Prediction
X_test = test_data(:, predictors);
y_pred = predict(model, X_test);

% 
if iscell(y_pred)
    y_pred = cellfun(@str2double, y_pred);
end

% Ensure that the predicted values are non-negative
y_pred(y_pred < 0) = 0;

%% 6. Generate submission file
if ismember('index', test_data.Properties.VariableNames)
    indices = test_data.index;
else
    indices = (1:length(y_pred))';
end

submission = table(indices, y_pred, 'VariableNames', {'index', 'price'});
writetable(submission, 'submission.csv');


%% 7. Evaluation
% Training set prediction
y_train_pred = predict(model, X_train);
if iscell(y_train_pred)
    y_train_pred = cellfun(@str2double, y_train_pred);
end

% Calculate 
train_rmse = sqrt(mean((y_train - y_train_pred).^2));
train_mae = mean(abs(y_train - y_train_pred));
train_r2 = 1 - sum((y_train - y_train_pred).^2) / sum((y_train - mean(y_train)).^2);

fprintf('\nModel Evaluation Results:\n');
fprintf('Training Set RMSE: %.2f\n', train_rmse);
fprintf('Training Set MAE:  %.2f\n', train_mae);
fprintf('Training Set R²:   %.4f\n', train_r2);

%% 8. 
figure;

% 
subplot(2,2,1);
scatter(y_train, y_train_pred, 20, 'b', 'filled', 'MarkerFaceAlpha', 0.5);
hold on;
plot([min(y_train), max(y_train)], [min(y_train), max(y_train)], 'r--', 'LineWidth', 1.5);
xlabel('Real Housing Prices');
ylabel('Predicting housing prices');
title(sprintf('Prediction vs Reality (RMSE=%.2f)', train_rmse));
grid on;


% 
subplot(2,2,2);
residuals = y_train - y_train_pred;
histogram(residuals, 30, 'FaceColor', [0.8, 0.2, 0.2], 'FaceAlpha', 0.7);
xlabel('Residual');
ylabel('Frequency');
title(sprintf('Residual Distribution (均值=%.1f)', mean(residuals)));
grid on;

% 
subplot(2,2,3);
histogram(y_pred, 30, 'FaceColor', [0.2, 0.6, 0.2], 'FaceAlpha', 0.7);
xlabel('Predicting housing prices');
ylabel('Frequency');
title('Test set prediction distribution');
grid on;

sgtitle('Random Forest Housing Price Prediction', 'FontSize', 14, 'FontWeight', 'bold');

%% 9. Save Model
save('trained_model.mat', 'model', 'predictors');


%% 10. Predictive Statistics

fprintf('Predicted Quantity: %d\n', length(y_pred));
fprintf('Predicted Mean: %.2f\n', mean(y_pred));
fprintf('Predicted Median: %.2f\n', median(y_pred));
fprintf('Prediction range: [%.2f, %.2f]\n', min(y_pred), max(y_pred));