%%
clear; clc;
data = readmatrix("data.csv");
x_1 = data(:,1);
x_2 = data(:,2);
x_3 = data(:,3);
x_4 = data(:,4);
x_5 = data(:,5);
x_6 = data(:,6);
y = data(:,7);
%%
omega = [x_1, x_2, x_3, x_4, x_5, x_6];

theta = omega \ y;

%%
n = 1050;
t = linspace(0, n, n)';

figure;
hold on; grid on;
scatter(t, y, 'r.');
scatter(t, omega*theta, 'b.');
