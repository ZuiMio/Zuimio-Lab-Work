import pandas as pd
import numpy as np
from scipy.optimize import curve_fit
import os
import matplotlib.pyplot as plt

# 设置绘图风格和字体，防止中文乱码 (MacOS使用 Arial Unicode MS, Windows使用 SimHei)
plt.rcParams['font.sans-serif'] = ['Arial Unicode MS', 'SimHei', 'sans-serif']
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# ==========================================
# 1. 候选函数定义 (用于辨识 x1, x2, x3 的类型)
# ==========================================
def f_sin(t, a, b, c, d): return a * np.sin(b * t + c) + d
def f_linear(t, a, b): return a * t + b
def f_poly2(t, a, b, c, d): return (a * t + d)**2 + b * t + c
def f_exp(t, a, b, c, d): return a * np.exp(b * t + d) + c
def f_sqrt(t, a, b, c, d): return a * np.sqrt(b * t + d) + c
def f_rational(t, a, b, c, d): return a / (b * t + d) + c
def f_inv_sqrt(t, a, b, c, d): return a / np.sqrt(b * t + d) + c
def f_inv_sq(t, a, b, c, d): return a / ((b * t + d)**2) + c

# 映射函数名到题目选项
func_map = {
    "sin": "a sin(bt+c) + d",
    "linear": "a t+b",
    "poly2": "(at+d)^2 + bt + c",
    "exp": "a exp(bt+d) + c",
    "sqrt": "a sqrt(bt + d) + c",
    "rational": "a/(bt+d) + c",
    "inv_sqrt": "a/sqrt(bt+d) + c",
    "inv_sq": "a/(bt+d)^2 + c"
}

def identify_component(t_data, x_data, label, ax=None):
    """
    辨识组件并绘图
    """
    best_mse = float('inf')
    best_type = "other"
    best_pred = None
    
    # 定义要测试的函数列表
    # 稍微调整了一些初始猜测值 p0 以提高 sin 的命中率
    candidates = [
        ('sin', f_sin, [5, 5, 0, 0]), 
        ('linear', f_linear, [1, 0]),
        ('poly2', f_poly2, [1, 1, 1, 1]),
        ('exp', f_exp, [1, -1, 0, 0]),
        ('sqrt', f_sqrt, [1, 1, 0, 1]),
        ('rational', f_rational, [1, 1, 0, 1]),
        ('inv_sqrt', f_inv_sqrt, [1, 1, 0, 1]),
        ('inv_sq', f_inv_sq, [1, 1, 0, 1])
    ]
    
    for name, func, p0 in candidates:
        try:
            popt, _ = curve_fit(func, t_data, x_data, p0=p0, maxfev=20000)
            x_pred = func(t_data, *popt)
            mse = np.mean((x_data - x_pred)**2)
            
            if mse < best_mse:
                best_mse = mse
                best_type = func_map[name]
                best_pred = x_pred
        except:
            continue
            
    print(f"Component {label}: Best Fit = {best_type} (MSE: {best_mse:.2e})")
    
    # 绘图部分
    if ax is not None:
        ax.scatter(t_data[::5], x_data[::5], s=10, color='blue', alpha=0.5, label='原始数据 (采样)')
        if best_pred is not None:
            ax.plot(t_data, best_pred, color='red', linewidth=2, label=f'拟合: {best_type}')
        ax.set_title(f"{label} 辨识结果")
        ax.legend()
        ax.grid(True, linestyle='--', alpha=0.6)

    return best_type

# ==========================================
# 主程序
# ==========================================
def main():
    base_path = r"/Users/zuimio/Desktop/ITMO/s7/Identification Theory/FinTest/1/30/task2"
    csv_path = os.path.join(base_path, "data.csv")
    txt_path = os.path.join(base_path, "t1.txt")
    
    # 1. 读取数据
    if not os.path.exists(csv_path):
        print("Error: data.csv not found.")
        return
    
    df = pd.read_csv(csv_path)
    t = df['t'].values
    x1 = df['x_1'].values
    x2 = df['x_2'].values
    x3 = df['x_3'].values
    y = df['y'].values
    
    # 读取目标时间 t1
    if os.path.exists(txt_path):
        with open(txt_path, 'r') as f:
            t1_target = float(f.read().strip())
    else:
        t1_target = 22.9024390243902

    
    # === 准备画布 Part 1: 组件辨识 ===
    fig1, axes1 = plt.subplots(3, 1, figsize=(10, 12))
    plt.subplots_adjust(hspace=0.4)
    fig1.suptitle("Part 1: Regressor Component Identification", fontsize=16)

    print("=== Part 1: Identification (Questions 1-3) ===")
    identify_component(t, x1, "x_1", ax=axes1[0])
    identify_component(t, x2, "x_2", ax=axes1[1])
    identify_component(t, x3, "x_3", ax=axes1[2])
    
    print("\n=== Part 2: Gradient Descent (Question 5) ===")
    # 梯度下降参数
    gamma = 1.0
    theta = np.array([0.0, 0.0, 0.0]) # Zero initial conditions
    
    # 用于绘图的数据记录
    theta_history = []
    error_history = []
    time_history = []
    
    found = False
    
    for i in range(len(t) - 1):
        # 记录当前状态
        theta_history.append(theta.copy())
        time_history.append(t[i])
        
        # 当前时间点的数据
        phi = np.array([x1[i], x2[i], x3[i]])
        
        # 计算误差 e = y - phi^T * theta
        prediction = np.dot(phi, theta)
        error = y[i] - prediction
        error_history.append(error)
        
        # 计算时间步长 dt
        dt = t[i+1] - t[i]
        
        # 欧拉法离散化更新
        theta = theta + dt * gamma * phi * error
        
        # 检查是否到达目标时间 t1
        if t[i+1] >= t1_target and not found:
            print(f"Reached target time t1 = {t1_target:.5f} at step index {i+1} (t={t[i+1]:.5f})")
            print("Estimate values:")
            print(f"Theta 1 (for x_1): {theta[0]}")
            print(f"Theta 2 (for x_2): {theta[1]}")
            print(f"Theta 3 (for x_3): {theta[2]}")
            
            # 在图上标记这个点所需的坐标
            target_idx = i
            target_time = t[i+1]
            target_thetas = theta
            found = True
            # 不 break，继续跑完以便画出完整的收敛曲线
            
    if not found:
        print(f"Warning: Time t1={t1_target} is beyond the data range.")

    # 转换为 numpy 数组方便切片
    theta_history = np.array(theta_history)
    
    # === 准备画布 Part 2: 参数收敛 ===
    fig2, axes2 = plt.subplots(2, 1, figsize=(10, 10))
    fig2.suptitle("Part 2: Gradient Descent Convergence", fontsize=16)
    
    # 图1: 参数 Theta 随时间变化
    ax_theta = axes2[0]
    ax_theta.plot(time_history, theta_history[:, 0], label=r'$\theta_1$ (for $x_1$)', linewidth=2)
    ax_theta.plot(time_history, theta_history[:, 1], label=r'$\theta_2$ (for $x_2$)', linewidth=2)
    ax_theta.plot(time_history, theta_history[:, 2], label=r'$\theta_3$ (for $x_3$)', linewidth=2)
    
    # 标记 t1 时刻
    if found:
        ax_theta.axvline(x=t1_target, color='k', linestyle='--', label=f'Target $t_1$={t1_target:.2f}')
        # 标出 t1 时刻的数值点
        ax_theta.scatter([t1_target]*3, target_thetas, color='black', zorder=5)

    ax_theta.set_xlabel('Time (t)')
    ax_theta.set_ylabel('Parameter Estimates')
    ax_theta.set_title('Parameter Convergence (Theta)')
    ax_theta.legend()
    ax_theta.grid(True)
    
    # 图2: 估计误差随时间变化
    ax_err = axes2[1]
    ax_err.plot(time_history, error_history, color='purple', alpha=0.7)
    ax_err.set_xlabel('Time (t)')
    ax_err.set_ylabel('Estimation Error (y - y_hat)')
    ax_err.set_title('Estimation Error Convergence')
    ax_err.grid(True)
    if found:
        ax_err.axvline(x=t1_target, color='k', linestyle='--')

    # 显示所有图表
    plt.show()

if __name__ == "__main__":
    main()