clear;
clc;

% Step 1: Load the data
data = readtable('data.csv');
t = data.t;
x1 = data.x_1;
x2 = data.x_2;
x3 = data.x_3;
y = data.y;

% 查看数据的基本统计特征
fprintf('数据统计特征:\n');
fprintf('变量\t均值\t标准差\t最小值\t最大值\n');
fprintf('t\t%.4f\t%.4f\t%.4f\t%.4f\n', mean(t), std(t), min(t), max(t));
fprintf('x1\t%.4f\t%.4f\t%.4f\t%.4f\n', mean(x1), std(x1), min(x1), max(x1));
fprintf('x2\t%.4f\t%.4f\t%.4f\t%.4f\n', mean(x2), std(x2), min(x2), max(x2));
fprintf('x3\t%.4f\t%.4f\t%.4f\t%.4f\n', mean(x3), std(x3), min(x3), max(x3));
fprintf('y\t%.4f\t%.4f\t%.4f\t%.4f\n', mean(y), std(y), min(y), max(y));

% 可视化数据
figure('Position', [100, 100, 1200, 800]);

subplot(2,2,1);
plot(t, x1, 'b-', 'LineWidth', 1.5);
xlabel('t');
ylabel('x_1');
title('x_1 vs t');
grid on;

subplot(2,2,2);
plot(t, x2, 'r-', 'LineWidth', 1.5);
xlabel('t');
ylabel('x_2');
title('x_2 vs t');
grid on;

subplot(2,2,3);
plot(t, x3, 'g-', 'LineWidth', 1.5);
xlabel('t');
ylabel('x_3');
title('x_3 vs t');
grid on;

subplot(2,2,4);
plot(t, y, 'm-', 'LineWidth', 1.5);
xlabel('t');
ylabel('y');
title('y vs t');
grid on;

% Step 2: 定义模型函数和初始参数
models = {
    struct('name', '正弦模型: a*sin(b*t+c)+d', 'func', @(p,t) p(1)*sin(p(2)*t + p(3)) + p(4), 'init', [1, 1, 0, 0]),
    struct('name', '线性模型: a*t+b', 'func', @(p,t) p(1)*t + p(2), 'init', [1, 0]),
    struct('name', '二次模型: a*t^2 + b*t + c', 'func', @(p,t) p(1)*t.^2 + p(2)*t + p(3), 'init', [1, 1, 0]),
    struct('name', '指数模型: a*exp(b*t)+c', 'func', @(p,t) p(1)*exp(p(2)*t) + p(3), 'init', [1, 0.1, 0]),
    struct('name', '平方根模型: a*sqrt(b*t)+c', 'func', @(p,t) p(1)*sqrt(p(2)*t) + p(3), 'init', [1, 1, 0]),
    struct('name', '倒数模型: a/(b*t+c)+d', 'func', @(p,t) p(1)./(p(2)*t + p(3)) + p(4), 'init', [1, 1, 1, 0]),
    struct('name', '平方根倒数模型: a/sqrt(b*t+c)+d', 'func', @(p,t) p(1)./sqrt(p(2)*t + p(3)) + p(4), 'init', [1, 1, 1, 0]),
    struct('name', '平方倒数模型: a/(b*t+c)^2+d', 'func', @(p,t) p(1)./(p(2)*t + p(3)).^2 + p(4), 'init', [1, 1, 1, 0])
};

% 要拟合的变量
variables = {'x1', 'x2', 'x3', 'y'};
variable_data = {x1, x2, x3, y};

% 存储结果
results = cell(length(variables), length(models));
best_models = cell(length(variables), 1);

% Step 3: 为每个变量拟合所有模型
for var_idx = 1:length(variables)
    fprintf('\n=== 拟合变量: %s ===\n', variables{var_idx});
    data_vec = variable_data{var_idx};
    
    min_mse = Inf;
    best_model_idx = 0;
    
    for model_idx = 1:length(models)
        model = models{model_idx};
        fprintf('\n尝试模型 %d: %s\n', model_idx, model.name);
        
        try
            % 使用非线性最小二乘拟合
            options = optimset('Display', 'off', 'MaxIter', 1000, 'TolFun', 1e-8);
            
            % 根据模型类型调整初始参数
            init_params = model.init;
            
            % 调整初始参数以适应数据范围
            if model_idx == 1 % 正弦模型
                init_params(1) = (max(data_vec) - min(data_vec))/2; % 振幅
                init_params(2) = 2*pi/(max(t)-min(t)); % 频率
                init_params(4) = mean(data_vec); % 偏移
            elseif model_idx == 4 % 指数模型
                init_params(1) = max(data_vec) - min(data_vec);
                init_params(2) = sign(mean(diff(data_vec)))*0.01;
                init_params(3) = min(data_vec);
            end
            
            % 拟合模型
            [params, ~, residual, ~, ~] = lsqcurvefit(model.func, init_params, t, data_vec, [], [], options);
            
            % 计算预测值
            y_pred = model.func(params, t);
            
            % 计算MSE和R²
            mse_val = mean((data_vec - y_pred).^2);
            ss_total = sum((data_vec - mean(data_vec)).^2);
            ss_residual = sum((data_vec - y_pred).^2);
            r_squared = 1 - ss_residual/ss_total;
            
            % 存储结果
            results{var_idx, model_idx} = struct(...
                'params', params, ...
                'mse', mse_val, ...
                'r2', r_squared, ...
                'y_pred', y_pred);
            
            fprintf('  MSE: %.6f, R²: %.4f\n', mse_val, r_squared);
            fprintf('  参数: ');
            fprintf('%.4f ', params);
            fprintf('\n');
            
            % 更新最佳模型
            if mse_val < min_mse
                min_mse = mse_val;
                best_model_idx = model_idx;
            end
            
        catch ME
            fprintf('  拟合失败: %s\n', ME.message);
            results{var_idx, model_idx} = struct('params', [], 'mse', Inf, 'r2', -Inf, 'y_pred', []);
        end
    end
    
    % 保存最佳模型信息
    best_models{var_idx} = struct(...
        'variable', variables{var_idx}, ...
        'model_idx', best_model_idx, ...
        'model_name', models{best_model_idx}.name, ...
        'mse', min_mse, ...
        'params', results{var_idx, best_model_idx}.params, ...
        'r2', results{var_idx, best_model_idx}.r2);
    
    fprintf('\n★ 最佳模型: %s\n', models{best_model_idx}.name);
    fprintf('  参数: ');
    fprintf('%.4f ', results{var_idx, best_model_idx}.params);
    fprintf('\n  MSE: %.6f, R²: %.4f\n', min_mse, results{var_idx, best_model_idx}.r2);
end

% Step 4: 显示所有变量的最佳模型
fprintf('\n\n========== 最佳模型总结 ==========\n');
for var_idx = 1:length(variables)
    best = best_models{var_idx};
    fprintf('\n变量 %s:\n', best.variable);
    fprintf('  模型: %s\n', best.model_name);
    fprintf('  参数: [');
    fprintf('%.4f ', best.params);
    fprintf(']\n');
    fprintf('  MSE: %.6f, R²: %.4f\n', best.mse, best.r2);
end

% Step 5: 可视化最佳拟合结果
figure('Position', [100, 100, 1400, 900]);
for var_idx = 1:length(variables)
    subplot(2,2,var_idx);
    data_vec = variable_data{var_idx};
    best = best_models{var_idx};
    
    if best.model_idx > 0
        y_pred = results{var_idx, best.model_idx}.y_pred;
        
        plot(t, data_vec, 'b-', 'LineWidth', 1.5, 'DisplayName', '实际数据');
        hold on;
        plot(t, y_pred, 'r--', 'LineWidth', 2, 'DisplayName', '模型拟合');
        hold off;
        
        xlabel('t');
        ylabel(variables{var_idx});
        title(sprintf('%s: %s\nMSE=%.4f, R²=%.4f', ...
            variables{var_idx}, best.model_name, best.mse, best.r2));
        legend('Location', 'best');
        grid on;
    else
        text(0.5, 0.5, '无有效拟合', 'HorizontalAlignment', 'center');
    end
end

% Step 6: 创建模型性能对比表
fprintf('\n\n========== 所有模型性能对比 (MSE) ==========\n');
fprintf('模型\t\t\t\t\tx1\t\tx2\t\tx3\t\ty\n');
fprintf('------------------------------------------------------------\n');

for model_idx = 1:length(models)
    fprintf('%-30s', models{model_idx}.name(1:min(30, length(models{model_idx}.name))));
    
    for var_idx = 1:length(variables)
        if ~isempty(results{var_idx, model_idx}) && isfield(results{var_idx, model_idx}, 'mse')
            mse_val = results{var_idx, model_idx}.mse;
            if mse_val < Inf
                fprintf('\t%.4f', mse_val);
            else
                fprintf('\tInf');
            end
        else
            fprintf('\tN/A');
        end
    end
    fprintf('\n');
end