clear;
clc;

% Step 1: Load the data
data = readtable('data.csv'); % Replace 'data.csv' with the full file path if needed
t1 = 21.3458294283037; % Given time t1
gamma = 1; % Adaptation gain
learning_rate = 0.001; % Learning rate
max_iter = 1000; % Maximum iterations
tolerance = 1e-6; % Convergence tolerance

% Step 2: Extract entire dataset for gradient descent
t = data.t;

% Construct the feature matrix using the optimal models from the problem
x1 = 0.0487 * t - 0.9504;  % Linear model: a*t + b
x2 = (0.0774 * t - 1.4234).^2 + 0.2203 * t - 5.0646;  % Quadratic model: (a*t + d)^2 + b*t + c
x3 = 10.2784 ./ ((-4.9437 * t - 1.2472).^2) - 0.0468;  % Reciprocal squared: a/(b*t + d)^2 + c

X = [x1, x2, x3]; % Construct the feature matrix
y = data.y; % Target variable

% Step 3: Initialize parameters
theta = [0; 0; 0]; % Initial values for theta_1, theta_2, theta_3
error_history = zeros(max_iter, 1); % For storing the error at each iteration

% Step 4: Gradient descent loop
for iter = 1:max_iter
    % Compute predictions
    y_pred = X * theta;
    
    % Compute error
    error = y_pred - y;
    
    % Compute Mean Squared Error (MSE)
    mse = mean(error.^2);
    error_history(iter) = mse;
    
    % Compute gradient
    grad = (2 / length(y)) * (X' * error);
    
    % Update parameters
    theta_new = theta - gamma * learning_rate * grad;
    
    % Check convergence
    if norm(theta_new - theta, 2) < tolerance
        theta = theta_new;
        fprintf('Converged after %d iterations\n', iter);
        break;
    end
    
    % Update theta
    theta = theta_new;
end

% If didn't converge by max_iter
if iter == max_iter
    fprintf('Reached maximum iterations (%d) without convergence\n', max_iter);
end

% Step 5: Extract data at t1 and compute estimate
% Compute x1, x2, x3 at t1 using the optimal models
x1_t1 = 0.0487 * t1 - 0.9504;
x2_t1 = (0.0774 * t1 - 1.4234)^2 + 0.2203 * t1 - 5.0646;
x3_t1 = 10.2784 / ((-4.9437 * t1 - 1.2472)^2) - 0.0468;

X_t1 = [x1_t1, x2_t1, x3_t1]; % Feature vector at t1
y_t1_estimate = X_t1 * theta; % Estimate at t1

% Step 6: Output results
fprintf('\nEstimated parameter values:\n');
fprintf('Theta_1: %.6f\n', theta(1));
fprintf('Theta_2: %.6f\n', theta(2));
fprintf('Theta_3: %.6f\n', theta(3));
fprintf('\nEstimate at t1 = %.6f: %.6f\n', t1, y_t1_estimate);

% Step 7: Plot error convergence
figure;
plot(1:iter, error_history(1:iter), 'b-', 'LineWidth', 1.5);
xlabel('Iteration');
ylabel('Mean Squared Error (MSE)');
title('Convergence of Gradient Descent');
grid on;