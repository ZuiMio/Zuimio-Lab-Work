clear;clc;

data = readtable('data.csv');
data_t1 = readtable('t1.txt');
t1 = data_t1.Var1;
x_1 = data.x_1;
x_2 = data.x_2;
x_3 = data.x_3;
t = transpose(linspace(0, 30, length(x_1)));
figure(1)
plot(t, x_1)
figure(2)
plot(t, x_2)
figure(3)
plot(t, x_3)

%% 使用新的八个模型定义

% 模型1: a * sin(b * t + c) + d
fun_1 = inline('c_1(1) * sin(c_1(2) * x + c_1(3)) + c_1(4)', 'c_1', 'x');

% 模型2: a * t + b
fun_2 = inline('c_2(1) * x + c_2(2)', 'c_2', 'x');

% 模型3: (a * t + d)^2 + b * t + c
fun_3 = inline('(c_3(1) * x + c_3(4)).^2 + c_3(2) * x + c_3(3)', 'c_3', 'x');

% 模型4: a * exp(b * t + d) + c
fun_4 = inline('c_4(1) * exp(c_4(2) * x + c_4(3)) + c_4(4)', 'c_4', 'x');

% 模型5: a * sqrt(b * t + d) + c
fun_5 = inline('c_5(1) * sqrt(c_5(2) * x + c_5(3)) + c_5(4)', 'c_5', 'x');

% 模型6: a / (b * t + d) + c
fun_6 = inline('c_6(1) ./ (c_6(2) * x + c_6(3)) + c_6(4)', 'c_6', 'x');

% 模型7: a / sqrt(b * t + d) + c
fun_7 = inline('c_7(1) ./ sqrt(c_7(2) * x + c_7(3)) + c_7(4)', 'c_7', 'x');

% 模型8: a / (b * t + d)^2 + c
fun_8 = inline('c_8(1) ./ (c_8(2) * x + c_8(3)).^2 + c_8(4)', 'c_8', 'x');

%% 检验第一个自变量与t的关系

% 修改初始参数，避免除以0或负数的平方根
x1_fun1 = lsqcurvefit(fun_1, [1, 1, 0, 1], t, x_1);
x1_fun2 = lsqcurvefit(fun_2, [1, 1], t, x_1);
x1_fun3 = lsqcurvefit(fun_3, [1, 1, 1, 1], t, x_1);
x1_fun4 = lsqcurvefit(fun_4, [1, 1, 0, 1], t, x_1);
x1_fun5 = lsqcurvefit(fun_5, [1, 1, 1, 1], t, x_1);
x1_fun6 = lsqcurvefit(fun_6, [1, 1, 1, 1], t, x_1); % 改为[1, 1, 1, 1]避免分母为0
x1_fun7 = lsqcurvefit(fun_7, [1, 1, 1, 1], t, x_1); % 改为[1, 1, 1, 1]避免sqrt负数
x1_fun8 = lsqcurvefit(fun_8, [1, 1, 1, 1], t, x_1); % 改为[1, 1, 1, 1]避免分母为0

% 计算残差
error_1 = norm(feval(fun_1, x1_fun1, t) - x_1) ^ 2;
error_2 = norm(feval(fun_2, x1_fun2, t) - x_1) ^ 2;
error_3 = norm(feval(fun_3, x1_fun3, t) - x_1) ^ 2;
error_4 = norm(feval(fun_4, x1_fun4, t) - x_1) ^ 2;
error_5 = norm(feval(fun_5, x1_fun5, t) - x_1) ^ 2;
error_6 = norm(feval(fun_6, x1_fun6, t) - x_1) ^ 2;
error_7 = norm(feval(fun_7, x1_fun7, t) - x_1) ^ 2;
error_8 = norm(feval(fun_8, x1_fun8, t) - x_1) ^ 2;

disp('x1 model errors:')
disp(['Model 1: ', num2str(error_1)]);
disp(['Model 2: ', num2str(error_2)]);
disp(['Model 3: ', num2str(error_3)]);
disp(['Model 4: ', num2str(error_4)]);
disp(['Model 5: ', num2str(error_5)]);
disp(['Model 6: ', num2str(error_6)]);
disp(['Model 7: ', num2str(error_7)]);
disp(['Model 8: ', num2str(error_8)]);

%% 检验第二个自变量与t的关系

x2_fun1 = lsqcurvefit(fun_1, [1, 1, 0, 1], t, x_2);
x2_fun2 = lsqcurvefit(fun_2, [1, 1], t, x_2);
x2_fun3 = lsqcurvefit(fun_3, [1, 1, 1, 1], t, x_2);
x2_fun4 = lsqcurvefit(fun_4, [1, 1, 0, 1], t, x_2);
x2_fun5 = lsqcurvefit(fun_5, [1, 1, 1, 1], t, x_2);
x2_fun6 = lsqcurvefit(fun_6, [1, 1, 1, 1], t, x_2);
x2_fun7 = lsqcurvefit(fun_7, [1, 1, 1, 1], t, x_2);
x2_fun8 = lsqcurvefit(fun_8, [1, 1, 1, 1], t, x_2);

% 计算残差
error_1 = norm(feval(fun_1, x2_fun1, t) - x_2) ^ 2;
error_2 = norm(feval(fun_2, x2_fun2, t) - x_2) ^ 2;
error_3 = norm(feval(fun_3, x2_fun3, t) - x_2) ^ 2;
error_4 = norm(feval(fun_4, x2_fun4, t) - x_2) ^ 2;
error_5 = norm(feval(fun_5, x2_fun5, t) - x_2) ^ 2;
error_6 = norm(feval(fun_6, x2_fun6, t) - x_2) ^ 2;
error_7 = norm(feval(fun_7, x2_fun7, t) - x_2) ^ 2;
error_8 = norm(feval(fun_8, x2_fun8, t) - x_2) ^ 2;

disp('x2 model errors:')
disp(['Model 1: ', num2str(error_1)]);
disp(['Model 2: ', num2str(error_2)]);
disp(['Model 3: ', num2str(error_3)]);
disp(['Model 4: ', num2str(error_4)]);
disp(['Model 5: ', num2str(error_5)]);
disp(['Model 6: ', num2str(error_6)]);
disp(['Model 7: ', num2str(error_7)]);
disp(['Model 8: ', num2str(error_8)]);

%% 检验第三个自变量与t的关系

x3_fun1 = lsqcurvefit(fun_1, [1, 1, 0, 1], t, x_3);
x3_fun2 = lsqcurvefit(fun_2, [1, 1], t, x_3);
x3_fun3 = lsqcurvefit(fun_3, [1, 1, 1, 1], t, x_3);
x3_fun4 = lsqcurvefit(fun_4, [1, 1, 0, 1], t, x_3);
x3_fun5 = lsqcurvefit(fun_5, [1, 1, 1, 1], t, x_3);
x3_fun6 = lsqcurvefit(fun_6, [1, 1, 1, 1], t, x_3);
x3_fun7 = lsqcurvefit(fun_7, [1, 1, 1, 1], t, x_3);
x3_fun8 = lsqcurvefit(fun_8, [1, 1, 1, 1], t, x_3);

% 计算残差
error_1 = norm(feval(fun_1, x3_fun1, t) - x_3) ^ 2;
error_2 = norm(feval(fun_2, x3_fun2, t) - x_3) ^ 2;
error_3 = norm(feval(fun_3, x3_fun3, t) - x_3) ^ 2;
error_4 = norm(feval(fun_4, x3_fun4, t) - x_3) ^ 2;
error_5 = norm(feval(fun_5, x3_fun5, t) - x_3) ^ 2;
error_6 = norm(feval(fun_6, x3_fun6, t) - x_3) ^ 2;
error_7 = norm(feval(fun_7, x3_fun7, t) - x_3) ^ 2;
error_8 = norm(feval(fun_8, x3_fun8, t) - x_3) ^ 2;

disp('x3 model errors:')
disp(['Model 1: ', num2str(error_1)]);
disp(['Model 2: ', num2str(error_2)]);
disp(['Model 3: ', num2str(error_3)]);
disp(['Model 4: ', num2str(error_4)]);
disp(['Model 5: ', num2str(error_5)]);
disp(['Model 6: ', num2str(error_6)]);
disp(['Model 7: ', num2str(error_7)]);
disp(['Model 8: ', num2str(error_8)]);