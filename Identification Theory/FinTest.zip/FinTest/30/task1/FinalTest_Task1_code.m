clear all
clc

data = readmatrix("data.csv");

Y = data(:, 7);
Phi = [data(:, 1), data(:, 2), data(:, 3), data(:, 4), data(:, 5), data(:, 6)];

th = inv(Phi'*Phi)*Phi'*Y;
