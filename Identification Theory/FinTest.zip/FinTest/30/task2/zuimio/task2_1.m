clear;
clc;
% Step 1: Load the data
data = readtable('data.csv'); % Replace 'data.csv' with the full file path if needed
t = data.t;
x1 = data.x_1;
x2 = data.x_2;
x3 = data.x_3;
y = data.y;
% Step 2: Define possible models for regression
models = {
@(t, a, b, c, d) a * sin(b * t + c) + d, % Model 1: sin(bt + c)
@(t, a, b, c, d) a * t + b, % Model 2: linear (at + b)
@(t, a, b, c, d) (a * t + d).^2 + b * t + c, % Model 3: quadratic
@(t, a, b, c, d) a * exp(b * t + d) + c, % Model 4: exponential
@(t, a, b, c, d) a * sqrt(b * t + d) + c, % Model 5: square root
@(t, a, b, c, d) a ./ (b * t + d) + c, % Model 6: reciprocal
@(t, a, b, c, d) a ./ sqrt(b * t + d) + c, % Model 7: square root
@(t, a, b, c, d) a ./ (b * t + d).^2 + c % Model 8: squared reciprocal
};
% Step 3: Find the best model for each x variable
best_model_idx = zeros(3, 1); % To store the best model index for x1, x2, x3
best_params = cell(3, 1); % To store the best parameters for x1, x2, x3
variables = {x1, x2, x3}; % The variables to fit
for var_idx = 1:3
current_var = variables{var_idx};
min_error = inf; % Initialize minimum error
for model_idx = 1:length(models)
% Current model
model = models{model_idx};
% Fit the model using non-linear least squares
options = optimset('Display', 'off');
initial_params = [1, 1, 1, 1]; % Initial guess for a, b, c, d
try
params = lsqcurvefit(@(p, t) model(t, p(1), p(2), p(3), p(4)), ...
initial_params, t, current_var, [], [], options);
catch
continue;
end
% Compute the error
predictions = model(t, params(1), params(2), params(3), params(4));
error = sum((current_var - predictions).^2);
% Update the best model if error is smaller
if error < min_error
min_error = error;
best_model_idx(var_idx) = model_idx;
best_params{var_idx} = params;
end
end
end
% Step 4: Display the best model for each x variable
model_names = {
'a * sin(b * t + c) + d', 
'a * t + b', 
'(a * t + d)^2 + b * t + c',
'a * exp(b * t + d) + c',
'a * sqrt(b * t + d) + c',
'a / (b * t + d) + c',
'a / sqrt(b * t + d) + c',
'a / (b * t + d)^2 + c'
};
disp('Best model for each variable:');
for var_idx = 1:3
fprintf('x_%d: %s\n', var_idx, model_names{best_model_idx(var_idx)});
fprintf('Parameters: a=%.4f, b=%.4f, c=%.4f, d=%.4f\n', best_params{var_idx});
end
learning_rate = 0.01;
tolerance = 1e-6;
max_iter = 1000;
initial_params = [1.0, 1.0, 1.0, 1.0];
for var_idx = 1:3
model = models{best_model_idx(var_idx)};
current_var = variables{var_idx};
[converged, iterations] = gradient_descent(model, t, current_var, y, initial_params, learning_rate, max_iter, tolerance);
fprintf('x_%d: Converged=%d, Iterations=%d\n', var_idx, converged, iterations);
end
% Step 5: Gradient Descent Analysis
function [converged, iterations] = gradient_descent(model, t, x, y, initial_params, learning_rate, max_iter, tolerance)
params = initial_params; % Initial parameters
for iter = 1:max_iter
% Compute predictions and error
predictions = model(t, params(1), params(2), params(3), params(4));
error = predictions - y;
% Numerical gradient
grad = zeros(size(params));
for i = 1:numel(params)
delta = zeros(size(params));
delta(i) = 1e-5;
perturbed_params = params + delta;
perturbed_error = model(t, perturbed_params(1), perturbed_params(2), perturbed_params(3), perturbed_params(4)) - y;
grad(i) = sum(perturbed_error.^2 - error.^2) / 1e-5;
end
% Update parameters
params = params - learning_rate * grad;
% Check for convergence
if norm(grad) < tolerance
converged = true;
iterations = iter;
return;
end
end
converged = false;
iterations = max_iter;
end
% Test gradient descent on the best models