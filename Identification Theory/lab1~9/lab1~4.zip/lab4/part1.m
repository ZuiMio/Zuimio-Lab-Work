clear;clc;
load case1.mat


%% 


Y = y;
M = 500;
N = length(t);

Phi = zeros(N, 1 + 2*M);

for i = 1:N
    Phi(i, 1) = 1;
    
    for n = 1:M
        Phi(i, 2*n) = cos(n * t(i));
        Phi(i, 2*n + 1) = sin(n * t(i));
    end
end

theta = inv(Phi' * Phi) * (Phi' * Y);
Y_hat = Phi * theta;


%%
figure(1);
hold on; grid on;
plot(t, Y);
plot(t, Y_hat);
legend('original', 'predict');

%% 
S = Phi' * Phi;
H1 = det(S);
H2 = cond(S);

%% LSQ RG
lambda = 0.1;
theta_rg = inv(Phi' * Phi + lambda * eye(size(Phi,2))) * (Phi' * Y);
Y_hat_rg = Phi * theta_rg;

%% CVX Ridge Regression
cvx_begin quiet
    variable theta_rgcvx(size(Phi,2))
    minimize( sum_square(Y - Phi * theta_rgcvx) + lambda * sum_square(theta_rgcvx) )
cvx_end
Y_hat_rgcvx = Phi * theta_rgcvx;

%% CVX LASSO Regression
cvx_begin quiet
    variable theta_lassocvx(size(Phi,2))
    minimize( sum_square(Y - Phi * theta_lassocvx) + lambda * norm(theta_lassocvx,1) )
cvx_end
Y_hat_lassocvx = Phi * theta_lassocvx;

%% Loss
loss_lsq = norm(Y - Y_hat)^2;
loss_rg = norm(Y - Y_hat_rg)^2;
loss_rgcvx = norm(Y - Y_hat_rgcvx)^2;
loss_lassocvx = norm(Y - Y_hat_lassocvx)^2;
%% Plot 
figure(2);
hold on; grid on;
plot(t, Y, 'LineWidth', 2);
plot(t, Y_hat, '--', 'LineWidth', 1);
plot(t, Y_hat_rg, '--', 'LineWidth', 1);
plot(t, Y_hat_rgcvx, '--', 'LineWidth', 1);
plot(t, Y_hat_lassocvx, '--', 'LineWidth', 1);
legend('original','LSQ', 'Ridge', 'Ridge CVX', 'LASSO CVX');

%% optimal lambda for R and L %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

lambda_range = logspace(-6, 2, 50);
loss_rg_range = zeros(size(lambda_range));
loss_lasso_range = zeros(size(lambda_range));

for i = 1:length(lambda_range)
    % Ridge Regression
    theta_rg_temp = inv(Phi' * Phi + lambda_range(i) * eye(size(Phi,2))) * (Phi' * Y);
    Y_hat_rg_temp = Phi * theta_rg_temp;
    loss_rg_range(i) = norm(Y - Y_hat_rg_temp)^2;
    
    % LASSO Regression with CVX
    cvx_begin quiet
        variable theta_lasso_temp(size(Phi,2))
        minimize( sum_square(Y - Phi * theta_lasso_temp) + lambda_range(i) * norm(theta_lasso_temp,1) )
    cvx_end
    Y_hat_lasso_temp = Phi * theta_lasso_temp;
    loss_lasso_range(i) = norm(Y - Y_hat_lasso_temp)^2;
end

% Find lambda with minimum loss
[~, idx_rg] = min(loss_rg_range);
[~, idx_lasso] = min(loss_lasso_range);

lambda_rg_opt = lambda_range(idx_rg);
lambda_lasso_opt = lambda_range(idx_lasso);

%%
% Ridge with optimal lambda
theta_rg_opt = inv(Phi' * Phi + lambda_rg_opt * eye(size(Phi,2))) * (Phi' * Y);
Y_hat_rg_opt = Phi * theta_rg_opt;

% LASSO with optimal lambda
cvx_begin quiet
    variable theta_lassocvx_opt(size(Phi,2))
    minimize( sum_square(Y - Phi * theta_lassocvx_opt) + lambda_lasso_opt * norm(theta_lassocvx_opt,1) )
cvx_end
Y_hat_lassocvx_opt = Phi * theta_lassocvx_opt;

%% loss
loss_rg_opt = norm(Y - Y_hat_rg_opt)^2;
loss_lassocvx_opt = norm(Y - Y_hat_lassocvx_opt)^2;

%% Plot
figure(3);
hold on; grid on;
plot(t, Y, 'LineWidth', 2);
plot(t, Y_hat, '--', 'LineWidth', 1);
plot(t, Y_hat_rg_opt, '--', 'LineWidth', 1);
plot(t, Y_hat_lassocvx_opt, '--', 'LineWidth', 1);
legend('original', 'LSQ', 'Ridge Optimal', 'LASSO Optimal');

