clear;clc;

t = (0:0.1:30)';

phi1 = sin(t);
phi2 = cos(t);
phi3 = 2*sin(t) + cos(t);

%% 1
% Phi = [phi1, phi2, phi3];
% theta_true = [2; -3; 1];
% y = Phi * theta_true;
% y_true = y;
% dist = round(2*rand(size(y)) - 1);
% y = Phi * theta_true + dist;

%% 2
dist = zeros(size(t));
dist(10) = 5;
dist(100) = -10;
Phi = [phi1, phi2, phi3];
y = Phi*[2; -3; 1] + dist;

%% Calculate properties to recognize multicollinearity
S = Phi' * Phi;
det_S = det(S);
cond_S = cond(S);
eig_S = eig(S);
[Q, R] = qr(S);


%% LSQ
theta_lsq = inv(Phi' * Phi) * (Phi' * y);
y_hat_lsq = Phi * theta_lsq;

%% Ridge Regression
lambda = 0.01;
theta_rg = inv(Phi' * Phi + lambda * eye(3)) * (Phi' * y);
y_hat_rg = Phi * theta_rg;

%% CVX Ridge Regression
lambda = 0.01;
cvx_begin quiet
    variable theta_rgcvx(3, 1)
    minimize( sum_square(y - Phi * theta_rgcvx) + lambda * sum_square(theta_rgcvx) )
cvx_end
y_hat_rgcvx = Phi * theta_rgcvx;

%% CVX LASSO Regression
lambda = 1e-5;
cvx_begin quiet
    variable theta_lassocvx(3, 1)
    minimize( sum_square(y - Phi * theta_lassocvx) + lambda * norm(theta_lassocvx,1) )
cvx_end
y_hat_lassocvx = Phi * theta_lassocvx;

%% Calculate Loss Functions
loss_lsq = norm(y - y_hat_lsq)^2;
loss_rg = norm(y - y_hat_rg)^2;
loss_rgcvx = norm(y - y_hat_rgcvx)^2;
loss_lassocvx = norm(y - y_hat_lassocvx)^2;

%% Plot results
figure(1);
hold on; grid on;
plot(t, y, 'LineWidth', 1);
% plot(t, y_true, 'LineWidth', 1);
plot(t, y_hat_lsq, '--', 'LineWidth', 1);
plot(t, y_hat_rg, '--', 'LineWidth', 1);
plot(t, y_hat_rgcvx, '--', 'LineWidth', 1);
plot(t, y_hat_lassocvx, '--', 'LineWidth', 1);
% legend('Dist', 'True', 'LSQ', 'Ridge', 'Ridge CVX', 'LASSO CVX');
legend('Original', 'LSQ', 'Ridge', 'Ridge CVX', 'LASSO CVX');