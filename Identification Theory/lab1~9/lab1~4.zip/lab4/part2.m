clear;clc;
load case4.mat

%% 
Y = y;
M = 200;
N = length(t);

Phi = ones(length(t), M+1);
for i = 1:M
    Phi(:, i+1) = t.^i/t(end).^i;
end

% LSQ
lambda_lsq = 1e-8; 
theta = inv(Phi' * Phi + lambda_lsq * eye(size(Phi,2))) * (Phi' * Y);
Y_hat = Phi * theta;

%% 
figure(1);
hold on; grid on;
plot(t, Y, 'LineWidth', 1);
plot(t, Y_hat, 'LineWidth', 1);
legend('original', 'predict');

%% RG with better lambda
lambda = 1e-2; 
theta_rg = inv(Phi' * Phi + lambda * eye(size(Phi,2))) * (Phi' * Y);
Y_hat_rg = Phi * theta_rg;

%% CVX Ridge Regression
lambda = 1e-4;
cvx_begin quiet
    variable theta_rgcvx(size(Phi,2))
    minimize( sum_square(Y - Phi * theta_rgcvx) + lambda * sum_square(theta_rgcvx) )
cvx_end
Y_hat_rgcvx = Phi * theta_rgcvx;

%% CVX LASSO Regression
lambda = 1e-4;
cvx_begin quiet
    variable theta_lassocvx(size(Phi,2))
    minimize( sum_square(Y - Phi * theta_lassocvx) + lambda * norm(theta_lassocvx,1) ) 
cvx_end
Y_hat_lassocvx = Phi * theta_lassocvx;

%% Plot 
figure(2);
hold on; grid on;
plot(t, Y, 'LineWidth', 1);
plot(t, Y_hat_rg, '--', 'LineWidth', 2);
plot(t, Y_hat_rgcvx, '--', 'LineWidth', 2);
plot(t, Y_hat_lassocvx, '--', 'LineWidth', 2);
legend('original', 'Ridge', 'Ridge CVX', 'LASSO CVX');