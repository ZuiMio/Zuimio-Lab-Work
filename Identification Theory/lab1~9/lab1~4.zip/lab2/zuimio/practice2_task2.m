%% Cases
% y = 2*x1 + 5*x2 + v; Pass all 5 Hypo
% y = -3*x1 + 8*x2 + v; Pass all 5 Hypo
% y = -5*x1 + 2*x2 + v; Fail H3
% y = 12*x1 - 8.3*x2 + v; Fail H5
% y = 7*x1 - 3*x2 + v;
% y = -2*x1 - 8*x2 + v;
% y = 1.1*x1 + 5.32*x2 + v;
% y = 1.1*x1 + 5.32*x2 + v;

% Useful function
% std - standard deviaton
% var - variance
% cov - co-variance
% corrcoef(A,B) - correlation 
% mean - expected value
% autocorr - autocorr function

%% Here complete the task
clear;
load case3.mat

phi = [x1, x2];
th = (phi'*phi) \ phi'*y;
y_hat = phi * th;
v = y - y_hat;

Hv = mean(v);
figure();
hold on; grid on;
scatter(1:length(y), y, '.');
plot(y_hat);

% H1 +
Hv = mean(v); % If Hv is zero -> good (Hv < eps)

% H2 + (if corr is not 1)
% 1. dependence between x1 and v

% H3 +  det must not be zero
phi_det = det(phi' * phi);

%% Error of Y: delta_Y = Y - Y_hat, where Y_hat is estimate
e1 = y - y_hat;


%% H1. Check expected value. Use mean(...) and hist(...) Pass
% Approve H1 if Ev < epsion * (v_max - v_min)
% 1. Choose eps = ...
% 2. Calculate condition eps * (v_max - v_min)
% 3. Compare mean value and condition abs(Ev) < eps * (v_max - v_min)
eps = 0.01;
Ev = mean(v);
v_range = max(v) - min(v);
condition_H1 = eps * v_range;

fprintf('H1 (Zero Mean): %s\n', ternary_str(abs(Ev) < condition_H1, 'PASS', 'FAIL'));

%% H2. Here we use correlation coefficients. Use corrcoef(...) Pass
% [ corr(phi1, phi1), corr(phi1, v) ]
% [ corr(v, phi1),    corr(v, v) ]
eps = 0.1;
corr_x1_v = corrcoef(x1, v);
corr_x2_v = corrcoef(x2, v);
corr_x1_v_value = corr_x1_v(1,2);
corr_x2_v_value = corr_x2_v(1,2);
fprintf('H2 (Uncorrelated): %s\n', ternary_str((abs(corr_x1_v_value) < eps && abs(corr_x2_v_value) < eps), 'PASS', 'FAIL'));

%% H3. det must not be zero

phi_det = det(phi' * phi);


%% H4. Check the variance in measumetns. Pass
% Split Phi to n parts and use var(...) in loop. 

figure();
hold on; grid on;
title("Noise")
plot(v)
ylabel("v")

% whole_variance = ;
window_size = 100;
whole_variance = [];

for i = 1:length(v) - window_size
    whole_variance(i) = var(v(i:i+window_size));
end

hold on; grid on;
title("Variance")
plot(whole_variance, 'r')
ylabel("v")
ylim([-2, 2])
legend('Noise', 'whole_variance')




%% H5. Check autocorelation for v
% values are bounded
figure;
autocorr(v);

