
%% y = sin(t)

t = (-2*pi:pi/100:2*pi)';
y = sin(t);
%% 

X_1 = [t, ones(size(t))];
X_2 = [t.^2, t, ones(size(t))];
X_3 = zeros(length(t), 11);
for i = 0:10
    X_3(:, 11-i) = t.^i;
end
X_3 = [t.^10, t.^9, t.^8, t.^7,t.^6, t.^5, t.^4, t.^3,  t.^2, t, ones(size(t))];

theta_1 = (X_1' * X_1) \ (X_1' * y);         % [a; b]
theta_2 = (X_2' * X_2) \ (X_2' * y);         % [a; b; c]
theta_3 = (X_3' * X_3) \ (X_3' * y);         % [a10; a9; ...; a0]

Y_1 = X_1 * theta_1;
Y_2 = X_2 * theta_2;
Y_3 = X_3 * theta_3;

J1 = (y - Y_1)' * (y - Y_1);
J2 = (y - Y_2)' * (y - Y_2);
J3 = (y- Y_3)' * (y- Y_3);

%% 
figure; % for the first approximation + validation data 
plot(t, y, '*')
hold on
plot(t, Y_1);% without noise
plot(t, Y_2); % without noise
plot(t, Y_3); % without noise
legend('y','Y1','Y2','Y3')




















