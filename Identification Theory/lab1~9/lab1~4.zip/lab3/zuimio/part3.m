
t = [1, 2, 3, 4, 5]';
phi = [t, t.^0];
theta = [5; 3];
y = phi*theta + [0, 10, 0, 0, 0]';
%% L2 Optimization
cvx_begin
    variable th_L2(2)
    minimize( 1/2 * sum( (y - phi*th_L2).^2 ) )
cvx_end
%% L1 Optimization
scatter(t, y, "filled")
hold on; grid on;
plot(t, phi*th_L2)