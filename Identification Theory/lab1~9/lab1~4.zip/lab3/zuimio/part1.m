% Consider linear regression 2*phi1 + 5*phi2 - 3*phi3

% Load case
clear;clc;
load case4.mat
%% 

% Define output Y and regressor Phi
Y = y;
Phi = [phi1, phi2, phi3];

%% Use LSQ estimator
% θ = (X'X)^(-1)X'y
% Find the estimate using LSQ method; Calculate Yhat and Error eY
th = (Phi' *Phi) \ Phi' * Y;
Yhat = Phi * th;
eY = Y - Yhat;
J = 1/2 * eY' * eY;

%% Weighet LSQ

% Calculate the variance
window = 10;
V = [];
for k = 1:length(eY)-window
    V(k) = var(eY(k:k+window));
end
sz = length(eY) - length(V);
sigma = diag([V, ones(1, sz) * V(end)]);

W = inv(sigma);   % Weight matrix is inverse of covariance
% Weighted least squares: θ = (X'WX)^(-1)X'Wy
th_w = (Phi' * W * Phi) \ (Phi' * W * Y);
Yhat_w = Phi * th_w;
eY_w = Y - Yhat_w;
J_w = 1/2 * eY_w' * eY_w;
%% Graphics (compare LSQ and WLSQ)

figure(1);
hold on; grid on;
plot(Y, 'b');
plot(Yhat, 'k', 'LineWidth', 1);
plot(Yhat_w, 'r', 'LineWidth', 1);
legend('Y', 'Yhat', 'Yhat_w');
hold off;

figure(2);
hold on; grid on;
plot(eY, 'b', 'LineWidth', 1);
plot(eY_w, 'r', 'LineWidth', 1);
legend('eY', 'eY_w');
hold off;
