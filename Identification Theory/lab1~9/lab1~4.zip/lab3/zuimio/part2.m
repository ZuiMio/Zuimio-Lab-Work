%% 1
clear; clc;

t = 0:pi/100:10*pi;
phi = [cos(t); sin(t)]';
theta_true = [5; 3];
y = phi * theta_true;

%% 2
theta1_range = linspace(0, 10, 100);
theta2_range = linspace(0, 10, 100);

%% 3
[Theta1, Theta2] = meshgrid(theta1_range, theta2_range);

%% 4
J = zeros(size(Theta1));

for i = 1:size(Theta1, 1)
    for j = 1:size(Theta1, 2)
        theta_ij = [Theta1(i,j); Theta2(i,j)];
        y_hat = phi * theta_ij;
        e = y - y_hat;

        J(i,j) = 0.5 * (e' * e);
    end
end


%% 5
figure;
surf(Theta1, Theta2, J);


%% 6 L1

J_L1 = zeros(size(Theta1));

for i = 1:size(Theta1, 1)
    for j = 1:size(Theta1, 2)
        theta_ij = [Theta1(i,j); Theta2(i,j)];
        y_hat = phi * theta_ij;
        e = abs(y - y_hat); 

        J_L1(i,j) = 0.5*sum(e);
    end
end

figure;
surf(Theta1, Theta2, J_L1);
