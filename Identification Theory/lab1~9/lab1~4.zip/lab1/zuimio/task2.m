load("pendulum.mat")

% 2. Build the extended regression
Y = tau;
phi1 = sin(q);
phi2 = dw;
Phi = [phi1, phi2];

% 3. Estimate unknown parameters via Least Square Method
th = (Phi' * Phi) \ (Phi' * Y);

% 4. Calculate output using parameters estimate
Y_est = Phi * th;

% 5. Calculate Loss function
J = mean((Y - Y_est).^2); 
fprintf('=== Simple Pendulum Model ===\n');
fprintf('MSE = %.6f\n', J);
fprintf('Parameters:\n');
fprintf('mgl = %.4f\n', -th(1));
fprintf('J = %.4f\n', th(2));
fprintf('\n');

%% 
figure(1) % for the first approximation + validation data 
plot(t, Y, '*')
hold on
plot(t, Y_est); % without noise
title('Simple Pendulum Model');
xlabel('Time');
ylabel('Torque');
legend('Measured', 'Estimated');

%% 
% Pendulum with friction: J*dw = tau - b*omega - mgl*sin(q)
load("pendulumWithFriction.mat")

% Build the extended regression
Y1 = tau;
phi11 = sin(q);
phi12 = dw;
phi13 = w;  % 添加角速度项
Phi1 = [phi11, phi12, phi13];

% Estimate unknown parameters via Least Square Method
th1 = (Phi1' * Phi1) \ (Phi1' * Y1);

% Calculate output using parameters estimate
Y1_est = Phi1 * th1;

% Calculate Loss function
J1 = mean((Y1 - Y1_est).^2);

% Extract parameters
mgl_est = -th1(1);  % -mgl*sin(q) term  
J1_est = th1(2);     % J*dw term
b1_est = -th1(3);    % -b*omega term

fprintf('=== Pendulum with Friction ===\n');
fprintf('MSE = %.6f\n', J1);
fprintf('Parameters:\n');
fprintf('mgl = %.4f\n', mgl_est);
fprintf('J = %.4f\n', J1_est);
fprintf('b = %.4f\n', b1_est);
fprintf('\n');

%% 
figure(2) % for the first approximation + validation data 
plot(t, Y1, '*')
hold on
plot(t, Y1_est); % without noise
title('Pendulum with Friction');
xlabel('Time');
ylabel('Torque');
legend('Measured', 'Estimated');

%% 
clear;
% J*dw = Kt*I - b*omega - mgl*sin(q)
load("pendulumWithFrictionAndDCMotor.mat")

% mechanical
Y_mech = dw;
Phi_mech = [I, w, sin(q)];  % [km*I, -b*w, -mgl*sin(q)]
th_mech = (Phi_mech' * Phi_mech) \ (Phi_mech' * Y_mech);
km_est = th_mech(1);
b_est = -th_mech(2);
mgl_est = -th_mech(3);

% 计算机械系统预测值和损失函数
Y_mech_est = Phi_mech * th_mech;
J_mech = mean((Y_mech - Y_mech_est).^2);

fprintf('MSE (mechanical) = %.6f\n', J_mech);
fprintf('km = %.4f Nm/A\n', km_est);
fprintf('b = %.4f Nms/rad\n', b_est);
fprintf('mgl = %.4f Nm\n', mgl_est);

% u = R*I + L*dI + ke*w
fprintf('\n=== DC Motor Pendulum - Electrical Parameters ===\n');
Y_elec = u;
Phi_elec = [I, dI, w];  % [R*I, L*dI, ke*w]
th_elec = (Phi_elec' * Phi_elec) \ (Phi_elec' * Y_elec);

% electrical
R_est = th_elec(1);
L_est = th_elec(2);
ke_est = th_elec(3);

% Calculate output using parameters estimate
Y_elec_est = Phi_elec * th_elec;
J_elec = mean((Y_elec - Y_elec_est).^2);

fprintf('MSE (electrical) = %.6f\n', J_elec);
fprintf('R = %.4f Ohm\n', R_est);
fprintf('L = %.4f H\n', L_est);
fprintf('ke = %.4f Vs/rad\n', ke_est);

% J
numerator = km_est * I - b_est * w - mgl_est * sin(q);
J_instant = numerator ./ dw;

% 去除异常值
valid_idx = abs(dw) > 0.01 * max(abs(dw));
J_est = mean(J_instant(valid_idx));

fprintf('J = %.4f kg·m²\n', J_est);


fprintf('\n=== Parameter Consistency Check ===\n');
fprintf('km/ke ratio = %.4f\n', km_est/ke_est);

% 计算整体性能
dw_pred = (km_est * I - b_est * w - mgl_est * sin(q)) / J_est;
J_total = mean((dw - dw_pred).^2);
fprintf('Overall system MSE = %.6f\n', J_total);

%% 
figure(3)
plot(t, Y_mech, 'g*')
hold on
plot(t, Y_mech_est, 'LineWidth', 1.5);
title('DC Motor Pendulum - Mechanical Model');
xlabel('Time');
ylabel('Angular Acceleration (rad/s²)');
legend('Measured dw', 'Estimated dw');