clear;clc;
data = importdata('data.csv');

t = data.data(:, 1);
x_1 = data.data(:, 2);
x_2 = data.data(:, 3);
x_3 = data.data(:, 4);
y = data.data(:, 5);

X = [ x_1, x_2, x_3];

% θ = (X'X)^(-1)X'y
theta = (X' * X) \ (X' * y);

fprintf('Estimated parameters using LSE:\n');
fprintf('θ₁ (x₁ coefficient) = %.6f\n', theta(1));
fprintf('θ₂ (x₂ coefficient) = %.6f\n', theta(2));
fprintf('θ₃ (x₃ coefficient) = %.6f\n', theta(3));

% 
y_hat = X * theta;

% 
residuals = y - y_hat;

%% 
mean_residuals = mean(residuals);
corr_res_x1 = corr(residuals, x_1);
corr_res_x2 = corr(residuals, x_2);
corr_res_x3 = corr(residuals, x_3);