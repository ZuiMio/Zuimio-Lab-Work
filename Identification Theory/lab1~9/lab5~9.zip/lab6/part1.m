clear; close all; clc;

% 系统参数
alpha = 0.3;    % 真实参数（未知）
beta = 5;       % 滤波器参数
T_sim = 30;     % 仿真时间

% 创建时间向量
t = 0:0.01:T_sim;

% 输入信号
u = sin(t);

% 模拟系统响应（用于生成测量数据）
% 解析解：y' + alpha*y = sin(t)
syms y_sym(t_sym)
eqn = diff(y_sym, t_sym) + alpha*y_sym == sin(t_sym);
cond = y_sym(0) == 0;
y_sol = dsolve(eqn, cond);
y = double(subs(y_sol, t_sym, t));

% 实现LRE系统
x = zeros(size(t));
phi = zeros(size(t));

% 使用数值方法计算滤波信号
for k = 2:length(t)
    dt = t(k) - t(k-1);
    
    % 计算滤波信号 H(s)[y] 和 H(s)[u]
    if k == 2
        Hy_prev = 0;
        Hu_prev = 0;
    else
        Hy_prev = phi(k-1);  % phi = -H(s)[y]
        Hu_prev = Hu(k-1);
    end
    
    % 使用前向欧拉法计算滤波器输出
    Hy = Hy_prev + dt * beta * (y(k) - Hy_prev);
    Hu = Hu_prev + dt * beta * (u(k) - Hu_prev);
    
    % 计算 x 和 phi
    x(k) = (y(k) - Hy)/dt - Hu;  % sH(s)[y] - H(s)[u] 的离散近似
    phi(k) = -Hy;
end

% 绘制 x(t) 和 phi(t)
figure;
subplot(2,1,1);
plot(t, x, 'b', 'LineWidth', 1.5);
grid on;
xlabel('时间 t');
ylabel('x(t)');
title('辅助信号 x(t)');

subplot(2,1,2);
plot(t, phi, 'r', 'LineWidth', 1.5);
grid on;
xlabel('时间 t');
ylabel('\phi(t)');
title('回归量 \phi(t)');

% 梯度下降法参数估计
gamma = 2.0;        % 学习率
theta_hat = zeros(size(t));  % 参数估计
theta_hat(1) = 0.1; % 初始估计值

for k = 2:length(t)
    % 梯度下降更新规则
    error = x(k) - phi(k) * theta_hat(k-1);
    theta_hat(k) = theta_hat(k-1) + gamma * phi(k) * error;
end

% 绘制参数估计结果
figure;
plot(t, theta_hat, 'g', 'LineWidth', 2);
hold on; grid on;
plot(t, alpha*ones(size(t)), 'r--', 'LineWidth', 2);

% 检查PE条件
T_window = 2*pi;
a_threshold = 0.1;

pe_condition = zeros(size(t));
for k = 1:length(t)
    t_start = max(1, find(t >= max(0, t(k)-T_window), 1));
    t_end = k;
    
    if t_end > t_start
        integral_value = trapz(t(t_start:t_end), phi(t_start:t_end).^2);
        pe_condition(k) = integral_value;
    else
        pe_condition(k) = 0;
    end
end

