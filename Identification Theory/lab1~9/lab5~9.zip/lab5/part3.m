clear; clc;

load pendulum.mat
Phi = [dw, sin(q)];
Y = tau;

%% 

gamma_values = [0.0005, 0.001, 0.005];
num_iterations = length(Y);
theta_hat_history = cell(length(gamma_values), 1);

for g_idx = 1:length(gamma_values)
    gamma = gamma_values(g_idx);
    
    theta_hat = zeros(2, num_iterations);
    theta_hat(:, 1) = [0.1; 7]; 
    
    for k = 1:num_iterations-1
        error = Y(k) - Phi(k, :) * theta_hat(:, k);
        theta_hat(:, k+1) = theta_hat(:, k) + gamma * Phi(k, :)' * error;
    end
    
    theta_hat_history{g_idx} = theta_hat;
end

%%
% J
figure;
hold on; grid on;
plot(t, theta_hat_history{1}(1, :), 'LineWidth', 1);
plot(t, theta_hat_history{2}(1, :), 'LineWidth', 1);
plot(t, theta_hat_history{3}(1, :), 'LineWidth', 1);
legend('0.0005', '0.001', '0.005')
title('J')


% mgl
figure;
hold on; grid on;
plot(t, theta_hat_history{1}(2, :), 'LineWidth', 1);
plot(t, theta_hat_history{2}(2, :), 'LineWidth', 1);
plot(t, theta_hat_history{3}(2, :), 'LineWidth', 1);
legend('0.0005', '0.001', '0.005')
title('mgl')
