clear; clc;

%% Task 2
t_fixed = 3;

theta_range = linspace(0, 6, 100);

alpha_true = 3;
y_true = alpha_true * sin(t_fixed);
phi = sin(t_fixed);

J_range = (y_true - phi * theta_range).^2;

theta_hat_0 = 0.5;

gamma = 60; 
num_iterations = 100;

theta_hat = zeros(1, num_iterations);
J_history = zeros(1, num_iterations);

theta_hat(1) = theta_hat_0;
J_history(1) = (y_true - phi * theta_hat(1))^2;

for k = 1:num_iterations-1
    error = y_true - phi * theta_hat(k);
    theta_hat(k+1) = theta_hat(k) + gamma * phi * error;
 
    J_history(k+1) = (y_true - phi * theta_hat(k+1))^2;
end

%% 

figure;
plot(theta_range, J_range, 'b-', 'LineWidth', 1); hold on;
stairs(theta_hat, J_history, 'r-', 'LineWidth', 1, 'MarkerSize', 6);
plot(alpha_true, 0, 'g*', 'MarkerSize', 1, 'LineWidth', 3);