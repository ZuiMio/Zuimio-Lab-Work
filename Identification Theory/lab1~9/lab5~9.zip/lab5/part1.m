clear; clc;

t = (0:0.1:30)';
y = 3*sin(t) + 0.5*cos(t);
phi = [sin(t), cos(t)];
th_e = zeros(size(phi));
th_e(1, :) = [0, 0]; % Initila conditions
gamma = 0.1;
for k = 1:size(th_e, 1)-1
    err = y(k) - phi(k, :)*th_e(k, :)';
    th_e(k+1, :) = th_e(k, :) + gamma*phi(k, :)*err;
end
figure()
hold on; grid on;
yline(3);
yline(0.5);
plot(t, th_e);


% 
% 
% 
% %% 
% t = (0:0.1:30)';
% 
% % y(t) = φ(t)^T * θ
% phi = [sin(t), cos(2*t)];
% theta_true = [3; 0.5];
% y = phi * theta_true;
% 
% %% 
% theta_hat = zeros(2,1);
% gamma = 0.1;
% 
% theta_history = zeros(length(t), 2);
% error_history = zeros(length(t), 1);
% 
% 
% for k = 1:length(t)-1
%     phi_k = phi(k,:)';
% 
%     e = y(k) - phi_k' * theta_hat;
% 
%     theta_hat = theta_hat + gamma * phi_k * e;
% 
%     theta_history(k+1,:) = theta_hat';
%     error_history(k+1) = e;
% end
% 
% 
% figure()
% hold on; grid on;
% yline(3);
% yline(0.5);
% plot(t, th_e);
% 
% %% 
% figure;
% 
% plot(t, theta_history(:,1), 'b-', 'LineWidth', 2); hold on;
% plot(t, theta_history(:,2), 'r-', 'LineWidth', 2);
% plot([t(1), t(end)], [theta_true(1), theta_true(1)], 'b--', 'LineWidth', 1);
% plot([t(1), t(end)], [theta_true(2), theta_true(2)], 'r--', 'LineWidth', 1);
% grid on;
% 
% 
% 
% 
% % 估计误差
% subplot(2,2,2);
% alpha_error = theta_history(:,1) - theta_true(1);
% beta_error = theta_history(:,2) - theta_true(2);
% plot(t, alpha_error, 'b-', t, beta_error, 'r-', 'LineWidth', 1.5);
% grid on;
% 
% % 预测误差
% subplot(2,2,3);
% plot(t, error_history, 'k-', 'LineWidth', 1.5);
% grid on;
% 
% % 真实值与预测值比较
% subplot(2,2,4);
% y_pred = phi * theta_hat;  % 最终参数的预测值
% plot(t, y, 'b-', 'LineWidth', 2); hold on;
% plot(t, y_pred, 'r--', 'LineWidth', 1.5);
% grid on;

% %% 最终估计结果
% fprintf('真实参数: α = %.2f, β = %.2f\n', theta_true(1), theta_true(2));
% fprintf('最终估计: α̂ = %.6f, β̂ = %.6f\n', theta_hat(1), theta_hat(2));
% fprintf('估计误差: Δα = %.6f, Δβ = %.6f\n', abs(theta_hat(1)-theta_true(1)), abs(theta_hat(2)-theta_true(2)));
% 
% % 验证不同学习率的效果
% fprintf('\n不同学习率的效果比较:\n');
% gammas = [0.01, 0.05, 0.1, 0.2];
% for i = 1:length(gammas)
%     theta_test = zeros(2,1);
%     for k = 1:length(t)-1
%         phi_k = phi(k,:)';
%         e = y(k) - phi_k' * theta_test;
%         theta_test = theta_test + gammas(i) * phi_k * e;
%     end
%     fprintf('γ = %.2f: α̂ = %.4f, β̂ = %.4f\n', gammas(i), theta_test(1), theta_test(2));
% end
% %% Plot
% figure(3);
% hold on; grid on;
% plot(t, Y, 'LineWidth', 2);
% plot(t, Y_hat, '--', 'LineWidth', 1);
% plot(t, Y_hat_rg_opt, '--', 'LineWidth', 1);
% plot(t, Y_hat_lassocvx_opt, '--', 'LineWidth', 1);
% legend('original', 'LSQ', 'Ridge Optimal', 'LASSO Optimal');
% 
