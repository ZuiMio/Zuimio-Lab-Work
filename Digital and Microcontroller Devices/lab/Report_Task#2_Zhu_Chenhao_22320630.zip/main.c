#include "stm32f401xe.h"
#include <stdint.h>

#define F_APB1 16000000U
#define BAUD   230400U

#define B 1
#define A 1
#define OMEGA 2

uint8_t sine_table[64] = {
 128,140,153,165,176,186,195,202,
 207,210,212,212,210,207,202,195,
 186,176,165,153,140,128,115,102,
 90, 79, 69, 60, 53, 48, 45, 43,
 43, 45, 48, 53, 60, 69, 79, 90,
102,115,128,140,153,165,176,186,
195,202,207,210,212,212,210,207,
202,195,186,176,165,153,140,128
};

uint8_t idx = 0;

static inline void USART2_Send(uint8_t data) {
    while(!(USART2->SR & USART_SR_TXE));
    USART2->DR = data;
}

void TIM2_IRQHandler(void)
{
    if (TIM2->SR & TIM_SR_UIF)
        TIM2->SR &= ~TIM_SR_UIF;

    uint8_t s = sine_table[idx];
    idx = (idx + OMEGA) & 0x3F;

    uint8_t y = B + (A * s / 128);

    USART2_Send(y);   // send only 1 byte: CPU can load it !!!!!!
}

int main(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB1ENR |= RCC_APB1ENR_USART2EN;

    GPIOA->MODER &= ~(3 << (2*2));
    GPIOA->MODER |=  (2 << (2*2));
    GPIOA->AFR[0] &= ~(0xF << (2*4));
    GPIOA->AFR[0] |=  (7 << (2*4));

    USART2->BRR = (F_APB1 / BAUD);
    USART2->CR1 = USART_CR1_UE | USART_CR1_TE;

    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;

    TIM2->PSC = 999;
    TIM2->ARR = 421;
    TIM2->DIER |= TIM_DIER_UIE;
    TIM2->CR1  |= TIM_CR1_CEN;

    NVIC_EnableIRQ(TIM2_IRQn);

    while(1);
}



// #include "stm32f401xe.h"
// #include <stdint.h>
// #define F_APB1 16000000U
// #define baud 115200U

// uint8_t t = 0;

// int main(void)
// {
// 	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN | RCC_AHB1ENR_GPIOCEN;
// 	GPIOA->MODER |= (1 << (0*2));
// 	GPIOA->MODER |= (0b10 << (2*2)); // Set PA2 to Alternate Function mode
// 	GPIOA->MODER |= (0b10 << (3*2)); // Set PA3 to Alternate Function mode
// 	GPIOA->AFR[0] |= (7 << (2*4)); // Set PA2 to AF7 (USART2_TX)
// 	GPIOA->AFR[0] |= (7 << (3*4)); // Set PA3 to AF7 (USART2_RX)
// 	RCC->APB1ENR |= RCC_APB1ENR_USART2EN; // Enable USART2 clock
// 	USART2->BRR = F_APB1/baud; // Set baud rate
// 	USART2->CR1 = USART_CR1_UE | USART_CR1_TE;
	
// 	for(;;)
// 	{
// 		if(GPIOC->IDR & (1 << 13))
// 		{
// 			GPIOA->BSRR |= (1 << 0); // Set PA0 high
// 		}
// 		else
// 		{
// 			t++;

// 			USART2->DR = t;
// 			GPIOA->BSRR |= (1 << 16); // Set PA0 low
// 		}
// 	};
// }
