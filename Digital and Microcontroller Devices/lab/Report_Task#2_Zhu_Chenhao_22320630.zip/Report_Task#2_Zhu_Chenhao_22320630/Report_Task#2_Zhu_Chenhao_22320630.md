# Course name

## Task 2


NAME: Zhu Chenhao
HDU ID: 22320630\
NAME: DingYaqi
HDU ID: 22320602\
NAME: Dong Siya
HDU ID: 22320601\
NAME: Cai Xuanhao
HDU ID: 22320605\
VARIANT: 92


---

### Work goal

* Gain experience in configuring Timers to generate periodic interrupts.

* Practice configuring and using the USART peripheral.

* Learn to send data from STM32 MCU to a PC via Serial Port.

* Visualize data using SerialPlot (or MATLAB).

* Work in Proteus Simulator with virtual serial interface.


### Proteus schematic

![alt text](pics/scmematic.png "Simulation sch")

### Code explonations



Enable clock for GPIOA
``` C
RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
``` 

Enable clock for USART2
``` C
RCC->APB1ENR |= RCC_APB1ENR_USART2EN;
``` 

// Configure PA2 as Alternate Function (AF7 = USART2_TX)
``` C
GPIOA->MODER &= ~(3 << (2*2));
GPIOA->MODER |=  (2 << (2*2));
GPIOA->AFR[0] &= ~(0xF << (2*4));
GPIOA->AFR[0] |=  (7 << (2*4));
``` 

// Set USART baud rate to 230400
USART2->BRR = (F_APB1 / BAUD);

``` 
// Enable USART2 and transmitter
``` C
USART2->CR1 = USART_CR1_UE | USART_CR1_TE;
``` 

// Enable clock for TIM2
``` C
RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
``` 

// Configure TIM2 to generate interrupts at 38 Hz
``` C
TIM2->PSC = 999;
TIM2->ARR = 421;
``` 

// Enable timer interrupt
``` C
TIM2->DIER |= TIM_DIER_UIE;
NVIC_EnableIRQ(TIM2_IRQn);
``` 



### Simulation results


![alt text](pics/virtual.png "Simulation sch")
![alt text](pics/serialPlot.png "Simulation sch")

### Summary

This project implements periodic sine wave data transmission using the STM32F401RE microcontroller. Timer 2 is configured to trigger interrupts at a fixed 38 Hz rate. In each interrupt event, the next sample of a sine wave is retrieved from a lookup table and transmitted through USART2 at a baud rate of 230400. The data is sent in raw binary form and visualized in SerialPlot as a continuous waveform. This task demonstrates timer configuration, interrupt handling, USART communication, and real-time data visualization.

---
## Full code listing


``` C
#include "stm32f401xe.h"
#include <stdint.h>

#define F_APB1 16000000U
#define BAUD   230400U

#define B 1
#define A 1
#define OMEGA 2

uint8_t sine_table[64] = {
 128,140,153,165,176,186,195,202,
 207,210,212,212,210,207,202,195,
 186,176,165,153,140,128,115,102,
 90, 79, 69, 60, 53, 48, 45, 43,
 43, 45, 48, 53, 60, 69, 79, 90,
102,115,128,140,153,165,176,186,
195,202,207,210,212,212,210,207,
202,195,186,176,165,153,140,128
};

uint8_t idx = 0;

static inline void USART2_Send(uint8_t data) {
    while(!(USART2->SR & USART_SR_TXE));
    USART2->DR = data;
}

void TIM2_IRQHandler(void)
{
    if (TIM2->SR & TIM_SR_UIF)
        TIM2->SR &= ~TIM_SR_UIF;

    uint8_t s = sine_table[idx];
    idx = (idx + OMEGA) & 0x3F;

    uint8_t y = B + (A * s / 128);

    USART2_Send(y);   // send only 1 byte: CPU can load it !!!!!!
}

int main(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB1ENR |= RCC_APB1ENR_USART2EN;

    GPIOA->MODER &= ~(3 << (2*2));
    GPIOA->MODER |=  (2 << (2*2));
    GPIOA->AFR[0] &= ~(0xF << (2*4));
    GPIOA->AFR[0] |=  (7 << (2*4));

    USART2->BRR = (F_APB1 / BAUD);
    USART2->CR1 = USART_CR1_UE | USART_CR1_TE;

    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;

    TIM2->PSC = 999;
    TIM2->ARR = 421;
    TIM2->DIER |= TIM_DIER_UIE;
    TIM2->CR1  |= TIM_CR1_CEN;

    NVIC_EnableIRQ(TIM2_IRQn);

    while(1);
}

```