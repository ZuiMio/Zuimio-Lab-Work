# Digital and Microcontroller Devices

## Task 1

NAME: Zhu Chenhao
HDU ID: 22320630\
NAME: DingYaqi
HDU ID: 22320602\
NAME: Dong Siya
HDU ID: 22320601\
NAME: Cai Xuanhao
HDU ID: 22320605\
VARIANT: 92


---

### Work goal

Acquaintance with the development environment.


### Proteus schematic

![alt text](pics/scmematic.png "Simulation sch")

### Code explonations

**1. Enabling Clocks for GPIOB and GPIOC**

This part of the code enables the clock for GPIOB and GPIOC, which are the ports used for the buttons and LEDs respectively.
``` C
RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN | RCC_AHB1ENR_GPIOCEN;
```
* RCC->AHB1ENR: This register controls the clocks for various peripherals connected to the AHB1 bus.

* RCC_AHB1ENR_GPIOBEN: This enables the clock for GPIOB.

* RCC_AHB1ENR_GPIOCEN: This enables the clock for GPIOC.


**2. Configuring GPIO Pins for Buttons and LEDs**

This code sets up PB8 and PB9 for the "up" and "down" buttons, respectively, and configures PC0-PC7 as outputs to control the LEDs.

``` C
GPIOB->MODER &= ~(0xF << (8 * 2));  // Clear mode for PB8 and PB9 (input mode)
GPIOC->MODER |= (0x5555 << (0 * 2));  // Set PC0-PC7 to output mode
GPIOC->OTYPER &= ~LED_MASK;           // Set PC0-PC7 to push-pull mode
GPIOC->OSPEEDR |= (0x5555 << (0 * 2)); // Set PC0-PC7 to high-speed mode
```
* GPIOB->MODER: Configures the pin modes for GPIOB. The mask 0xF << (8 * 2) clears the previous configuration for PB8 and PB9, setting them as input.

* GPIOC->MODER: Configures PC0-PC7 as output pins to control the LEDs.

* GPIOC->OTYPER: Sets PC0-PC7 to push-pull mode (default output type).

* GPIOC->OSPEEDR: Configures the speed of the GPIO pins for higher performance (high-speed mode).

**3. Displaying Counter on LEDs**
This function updates the LEDs based on the current counter value. The counter value is displayed in binary format, with each bit controlling an individual LED (PC0-PC7).
``` C
void display_counter(void)
{
    GPIOC->ODR = (GPIOC->ODR & ~LED_MASK) | (counter & LED_MASK); // Update LEDs based on the counter value
}
```
* GPIOC->ODR: This register controls the output data for GPIOC (PC0-PC7). We use the bitwise AND (& ~LED_MASK) to clear the previous LED states and then the bitwise OR (| (counter & LED_MASK)) to set the new LED states based on the counter value.

**4. Handling Button Presses and Debouncing**
The code uses a simple state machine to detect button presses and updates the counter accordingly. A small delay is used to debounce the buttons and avoid multiple counts for a single press.
``` C
if (up_state == 0 && last_up_state == 1)  // Button pressed (transition from high to low)
{
    if (counter < 255)  // Prevent overflow
        counter++;
    display_counter();
    delay(50000);  // Delay for debounce
}
```
* This block checks if the "up" button (PB8) was pressed by detecting a transition from high to low (last_up_state == 1 and up_state == 0).

* After the press, the counter is incremented, the LEDs are updated, and a small delay is introduced to debounce the button.


**5. Delay for Debouncing**
A simple delay function is used to introduce a short pause after each button press to avoid misreads caused by button bounce.
``` C
void delay(volatile uint32_t time)
{
    while (time--);
}
```
* This function simply runs a loop that takes a set amount of time to complete, allowing the system to wait before detecting the next button press.

### Simulation results
UP
<div style="display: flex; justify-content: space-between; gap: 10px;">
    <img src="pics/1.png" alt="1" style="width: 30%; height: auto;">
    <img src="pics/2.png" alt="2" style="width: 30%; height: auto;">
    <img src="pics/3.png" alt="3" style="width: 30%; height: auto;">
</div>
DOWN
<div style="display: flex; justify-content: space-between; gap: 10px;">
    <img src="pics/32.png" alt="32" style="width: 30%; height: auto;">
    <img src="pics/31.png" alt="31" style="width: 30%; height: auto;">
    <img src="pics/30.png" alt="30" style="width: 30%; height: auto;">
</div>
After Pressing "Up": LEDs turn on one by one (starting from PC0) as the counter increments.

After Pressing "Down": LEDs turn off one by one as the counter decrements.
### Summary
In this project, we created a simple binary counter controlled by two buttons ("up" and "down"). The counter value is displayed in binary on 8 LEDs (PC0 to PC7).

We configured GPIO pins for the buttons (PB8 and PB9) and LEDs (PC0 to PC7).

The program detects button presses, increments or decrements the counter accordingly, and updates the LEDs.

A debouncing mechanism was implemented to ensure stable button inputs and prevent multiple detections for a single press.

This project demonstrates basic GPIO manipulation, button handling with debouncing, and binary representation of a counter on an embedded system (STM32).

---
## Full code listing


``` C
#include "stm32f401xe.h"
#include <stdint.h>

#define UP_BUTTON_PIN    (1 << 8)  // PB8
#define DOWN_BUTTON_PIN  (1 << 9)  // PB9
#define LED_MASK         0xFF      // PC0-PC7

volatile uint8_t counter = 0;  // 8-bit counter (0-255)
volatile uint8_t last_up_state = 1;  // Last state of the UP button (1 = not pressed, 0 = pressed)
volatile uint8_t last_down_state = 1;  // Last state of the DOWN button (1 = not pressed, 0 = pressed)

// Function to initialize GPIO ports
void init_GPIO(void)
{
    // Enable clocks for GPIOB and GPIOC
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN | RCC_AHB1ENR_GPIOCEN;
    
    // Configure PB8 and PB9 as input (for buttons)
    GPIOB->MODER &= ~(0xF << (8 * 2));  // Clear mode for PB8 and PB9 (input mode)
    
    // Configure PC0-PC7 as output (for LEDs)
    GPIOC->MODER |= (0x5555 << (0 * 2));  // Set PC0-PC7 to output mode
    GPIOC->OTYPER &= ~LED_MASK;           // Set PC0-PC7 to push-pull mode
    GPIOC->OSPEEDR |= (0x5555 << (0 * 2)); // Set PC0-PC7 to high-speed mode
}

// Function to display the counter on LEDs
void display_counter(void)
{
    GPIOC->ODR = (GPIOC->ODR & ~LED_MASK) | (counter & LED_MASK); // Update LEDs based on the counter value
}

// Function to delay (for debouncing and slowing down the loop)
void delay(volatile uint32_t time)
{
    while (time--);
}

int main(void)
{
    init_GPIO();  // Initialize GPIO for buttons and LEDs
    
    while (1)
    {
        // Read the state of the "up" button (PB8)
        uint8_t up_state = (GPIOB->IDR & UP_BUTTON_PIN) ? 1 : 0;  // If PB8 is high, button not pressed (1), otherwise pressed (0)
        
        // Detect rising edge (button press event)
        if (up_state == 0 && last_up_state == 1)  // Button pressed (transition from high to low)
        {
            if (counter < 255)  // Prevent overflow
                counter++;
            display_counter();
            delay(50000);  // Delay for debounce
        }
        
        last_up_state = up_state;  // Update last state of the "up" button
        
        // Read the state of the "down" button (PB9)
        uint8_t down_state = (GPIOB->IDR & DOWN_BUTTON_PIN) ? 1 : 0;  // If PB9 is high, button not pressed (1), otherwise pressed (0)
        
        // Detect rising edge (button press event)
        if (down_state == 0 && last_down_state == 1)  // Button pressed (transition from high to low)
        {
            if (counter > 0)  // Prevent underflow
                counter--;
            display_counter();
            delay(50000);  // Delay for debounce
        }
        
        last_down_state = down_state;  // Update last state of the "down" button
    }
}

```